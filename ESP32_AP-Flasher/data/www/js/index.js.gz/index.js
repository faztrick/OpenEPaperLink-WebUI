// OpenEPL ESP32 - Module Index
// Central module loading and dependency management

/**
 * Module Loader
 * Manages loading order and dependencies of all JavaScript modules
 */
class ModuleLoader {
    constructor() {
        this.modules = new Map();
        this.loadedModules = new Set();
        this.loadingPromises = new Map();
        
        // Add safety check for standalone pages
        if (this.isStandalonePage()) {
            console.log('Standalone page detected in ModuleLoader, skipping initialization');
            return;
        }
        
        this.defineModules();
    }

    /**
     * Check if this is a standalone page
     */
    isStandalonePage() {
        const path = window.location.pathname;
        const standalonePaths = ['/setup.html', '/setup', '/edit.html', '/edit'];
        return standalonePaths.some(p => path.includes(p)) || 
               document.title.includes('setup') || 
               document.title.includes('demo') ||
               document.title.includes('test');
    }

    /**
     * Define all modules and their dependencies
     */
    defineModules() {
        // Core utilities (no dependencies)
        this.modules.set('constants', {
            path: 'js/constants.js',
            dependencies: []
        });

        this.modules.set('utils', {
            path: 'js/utils.js',
            dependencies: ['constants']
        });

        // Performance monitoring (minimal dependencies)
        this.modules.set('performance', {
            path: 'js/performance.js',
            dependencies: ['utils']
        });

        // UI components (depends on utils)
        this.modules.set('ui-components', {
            path: 'js/ui-components.js',
            dependencies: ['utils', 'constants']
        });

        // Canvas renderer (depends on utils)
        this.modules.set('canvas-renderer', {
            path: 'js/canvas-renderer.js',
            dependencies: ['utils', 'constants']
        });

        // Tag manager (depends on multiple modules)
        this.modules.set('tag-manager', {
            path: 'js/tag-manager.js',
            dependencies: ['utils', 'constants', 'ui-components']
        });

        // Main application core (depends on all modules)
        this.modules.set('app-core', {
            path: 'js/app-core.js',
            dependencies: ['constants', 'utils', 'performance', 'ui-components', 'canvas-renderer', 'tag-manager']
        });
    }

    /**
     * Load a module and its dependencies
     */
    async loadModule(moduleName) {
        if (this.loadedModules.has(moduleName)) {
            return true;
        }

        if (this.loadingPromises.has(moduleName)) {
            return this.loadingPromises.get(moduleName);
        }

        const moduleInfo = this.modules.get(moduleName);
        if (!moduleInfo) {
            throw new Error(`Unknown module: ${moduleName}`);
        }

        const loadPromise = this._loadModuleWithDependencies(moduleName, moduleInfo);
        this.loadingPromises.set(moduleName, loadPromise);

        return loadPromise;
    }

    /**
     * Load module with its dependencies
     */
    async _loadModuleWithDependencies(moduleName, moduleInfo) {
        try {
            // Load dependencies first
            for (const dependency of moduleInfo.dependencies) {
                await this.loadModule(dependency);
            }

            // Load the module itself
            await this._loadScript(moduleInfo.path);
            
            this.loadedModules.add(moduleName);
            this.loadingPromises.delete(moduleName);
            
            console.log(`Module loaded: ${moduleName}`);
            return true;

        } catch (error) {
            this.loadingPromises.delete(moduleName);
            throw new Error(`Failed to load module ${moduleName}: ${error.message}`);
        }
    }

    /**
     * Load a script file
     */
    _loadScript(path) {
        return new Promise((resolve, reject) => {
            // Check if script is already loaded
            const existingScript = document.querySelector(`script[src="${path}"]`);
            if (existingScript) {
                resolve();
                return;
            }

            const script = document.createElement('script');
            script.src = path;
            script.async = true;
            
            script.onload = () => {
                resolve();
            };
            
            script.onerror = () => {
                reject(new Error(`Failed to load script: ${path}`));
            };
            
            document.head.appendChild(script);
        });
    }

    /**
     * Load all modules in dependency order
     */
    async loadAllModules() {
        const moduleNames = Array.from(this.modules.keys());
        
        try {
            // Load core modules first
            await this.loadModule('constants');
            await this.loadModule('utils');
            
            // Load system modules
            await this.loadModule('performance');
            
            // Load UI modules
            await this.loadModule('ui-components');
            await this.loadModule('canvas-renderer');
            
            // Load feature modules
            await this.loadModule('tag-manager');
            
            // Load main application
            await this.loadModule('app-core');
            
            console.log('All modules loaded successfully');
            return true;
            
        } catch (error) {
            console.error('Module loading failed:', error);
            throw error;
        }
    }

    /**
     * Get loading status
     */
    getStatus() {
        return {
            totalModules: this.modules.size,
            loadedModules: this.loadedModules.size,
            loadedModuleNames: Array.from(this.loadedModules),
            pendingModules: Array.from(this.loadingPromises.keys())
        };
    }

    /**
     * Check if all modules are loaded
     */
    isFullyLoaded() {
        return this.loadedModules.size === this.modules.size;
    }
}

/**
 * Legacy compatibility layer
 * Provides backward compatibility for existing code
 */
class LegacyCompatibility {
    constructor() {
        this.shimmed = new Set();
    }

    /**
     * Create compatibility shims for legacy code
     */
    createShims() {
        // Ensure global functions are available
        this.shimGlobalFunctions();
        
        // Ensure global variables are available
        this.shimGlobalVariables();
        
        // Create aliases for renamed functions
        this.createAliases();
    }

    /**
     * Shim global functions that may be expected by legacy code
     */
    shimGlobalFunctions() {
        if (!window.$) {
            window.$ = (selector) => document.querySelector(selector);
            this.shimmed.add('$');
        }

        if (!window.showStatusMessage) {
            window.showStatusMessage = (message, type = 'info') => {
                console.log(`[${type.toUpperCase()}] ${message}`);
            };
            this.shimmed.add('showStatusMessage');
        }

        if (!window.updateElement) {
            window.updateElement = (id, content) => {
                const element = document.getElementById(id);
                if (element) {
                    element.textContent = content;
                }
            };
            this.shimmed.add('updateElement');
        }
    }

    /**
     * Shim global variables
     */
    shimGlobalVariables() {
        if (!window.tagDB) {
            window.tagDB = {};
            this.shimmed.add('tagDB');
        }

        if (!window.contentCards) {
            window.contentCards = [];
            this.shimmed.add('contentCards');
        }
    }

    /**
     * Create aliases for renamed functions
     */
    createAliases() {
        // Add any function aliases needed for backward compatibility
        if (window.formatUptime && !window.displayTime) {
            window.displayTime = window.formatUptime;
            this.shimmed.add('displayTime');
        }
    }

    /**
     * Get shimmed items
     */
    getShimmedItems() {
        return Array.from(this.shimmed);
    }
}

/**
 * Application Initializer
 * Manages the complete application startup process
 */
class AppInitializer {
    constructor() {
        this.moduleLoader = new ModuleLoader();
        this.legacyCompat = new LegacyCompatibility();
        this.initStartTime = performance.now();
    }

    /**
     * Initialize the complete application
     */
    async initialize() {
        try {
            console.log('Starting OpenEPL ESP32 Application...');
            
            // Show loading indicator
            this.showLoadingIndicator();
            
            // Create legacy compatibility layer
            this.legacyCompat.createShims();
            
            // Load all modules
            await this.moduleLoader.loadAllModules();
            
            // Wait for DOM to be ready
            await this.waitForDOM();
            
            // Initialize application
            await this.initializeApplication();
            
            // Hide loading indicator
            this.hideLoadingIndicator();
            
            const initTime = performance.now() - this.initStartTime;
            console.log(`Application initialized in ${initTime.toFixed(2)}ms`);
            
        } catch (error) {
            console.error('Application initialization failed:', error);
            this.showErrorMessage(error);
        }
    }

    /**
     * Wait for DOM to be ready
     */
    waitForDOM() {
        return new Promise((resolve) => {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', resolve);
            } else {
                resolve();
            }
        });
    }

    /**
     * Initialize the main application
     */
    async initializeApplication() {
        // The OptimizedApp class should now be available
        if (typeof OptimizedApp !== 'undefined') {
            window.app = new OptimizedApp();
        } else {
            throw new Error('OptimizedApp class not found - app-core module may have failed to load');
        }
    }

    /**
     * Show loading indicator
     */
    showLoadingIndicator() {
        const loadingDiv = document.createElement('div');
        loadingDiv.id = 'appLoading';
        loadingDiv.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
                        background: rgba(0,0,0,0.8); display: flex; align-items: center; 
                        justify-content: center; z-index: 9999; color: white; font-family: Arial;">
                <div style="text-align: center;">
                    <div style="font-size: 24px; margin-bottom: 20px;">OpenEPL ESP32</div>
                    <div style="font-size: 16px;">Loading application modules...</div>
                    <div style="margin-top: 20px;">
                        <div style="width: 200px; height: 4px; background: #333; border-radius: 2px;">
                            <div id="loadingProgress" style="width: 0%; height: 100%; background: #007bff; 
                                                           border-radius: 2px; transition: width 0.3s;"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(loadingDiv);
        
        // Update progress
        this.updateLoadingProgress();
    }

    /**
     * Update loading progress
     */
    updateLoadingProgress() {
        const progressBar = document.getElementById('loadingProgress');
        if (!progressBar) return;
        
        const updateProgress = () => {
            const status = this.moduleLoader.getStatus();
            const progress = (status.loadedModules / status.totalModules) * 100;
            progressBar.style.width = `${progress}%`;
            
            if (!this.moduleLoader.isFullyLoaded()) {
                setTimeout(updateProgress, 100);
            }
        };
        
        updateProgress();
    }

    /**
     * Hide loading indicator
     */
    hideLoadingIndicator() {
        const loadingDiv = document.getElementById('appLoading');
        if (loadingDiv) {
            loadingDiv.style.opacity = '0';
            setTimeout(() => {
                loadingDiv.remove();
            }, 300);
        }
    }

    /**
     * Show error message
     */
    showErrorMessage(error) {
        const errorDiv = document.createElement('div');
        errorDiv.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
                        background: rgba(0,0,0,0.9); display: flex; align-items: center; 
                        justify-content: center; z-index: 9999; color: white; font-family: Arial;">
                <div style="text-align: center; max-width: 500px; padding: 20px;">
                    <div style="font-size: 24px; margin-bottom: 20px; color: #ff6b6b;">
                        Application Error
                    </div>
                    <div style="font-size: 16px; margin-bottom: 20px;">
                        Failed to load the application. Please check the console for details.
                    </div>
                    <div style="font-size: 14px; color: #ccc; margin-bottom: 20px;">
                        Error: ${error.message}
                    </div>
                    <button onclick="location.reload()" 
                            style="padding: 10px 20px; background: #007bff; color: white; 
                                   border: none; border-radius: 5px; cursor: pointer;">
                        Reload Page
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(errorDiv);
    }
}

// Auto-initialize when this script loads
document.addEventListener('DOMContentLoaded', () => {
    const initializer = new AppInitializer();
    initializer.initialize();
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ModuleLoader, LegacyCompatibility, AppInitializer };
}
